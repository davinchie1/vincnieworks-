ADE ADERELE WEBSITE: HOW TO PUT IT LIVE ON GODADDY
==================================================

What's in this folder
---------------------
index.html    The website (one page)
privacy.html  Privacy policy page (linked from every form and the footer)
images/       All photos and logos

STEP 1: Set up the form inbox (about 5 minutes, do this first)
---------------------------------------------------------------
GoDaddy web hosting can't email form entries on its own, so the forms use
Formspree, a form service.

1. Go to formspree.io and sign up with info@davinchieworks.com
   (confirm the email it sends you).
2. Click "+ New form". Name it "Website leads". Make sure the
   recipient email is info@davinchieworks.com.
3. Formspree shows your form endpoint. It looks like:
      https://formspree.io/f/abcdwxyz
   Copy it.
4. Open index.html in a plain text editor (Notepad on Windows,
   TextEdit on Mac in plain-text mode). Near the bottom, find this line:
      var FORM_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID";
   Replace the link with yours, keep the quotes, and save.

All five forms use this one endpoint. Each email arrives with its own
subject line so you can sort leads at a glance:
   New lead: Home search
   New lead: Home valuation
   New lead: Investor deals
   New lead: Relocation
   New lead: Call request

Note: Formspree's free plan limits how many submissions you get each
month. Check its pricing page and upgrade once leads pick up.

STEP 2: Upload to GoDaddy
-------------------------
1. Sign in to GoDaddy > My Products > Web Hosting > Manage > cPanel Admin.
2. Open "File Manager", then open the "public_html" folder.
   (If there's an old index.html or a "coming soon" page there,
   delete or rename it first.)
3. Click "Upload" and upload the website zip file.
4. Back in File Manager, right-click the zip > "Extract" into public_html.
   Make sure index.html, privacy.html and the images folder sit
   directly inside public_html, not inside another folder.
5. Visit https://davinchieworks.com. The site should load.

STEP 3: Test before you announce it
-----------------------------------
- Open each of the five forms, fill it in, and submit.
  You should see the thank-you message, and an email should arrive
  at info@davinchieworks.com within a minute or two.
- The first submission may ask you to confirm the form in Formspree.
  Click the link in that email.
- Check the site on your phone.
- Make sure the site loads with https:// (the padlock). If it doesn't,
  turn on SSL in GoDaddy (My Products > SSL).

Before launch (from your checklist)
-----------------------------------
- Copperplate Gothic Light is a paid font. Visitors without it see
  Copperplate (Mac) or Cinzel. Buy a web license if you want everyone
  to see it, and I can add it to the site.
- Confirm you have the rights to the Atlanta stock photo, the Cumming
  lake photo and the Win photo with the MLS watermark.
- Ask the photographer (Mide Wey) whether a photo credit is needed.
- Check HomeSmart's logo and advertising rules with your broker.
- Have your broker review privacy.html.

To change text later
--------------------
Open index.html in a text editor, find the words, change them, save,
and re-upload the file to public_html (replace the old one).
